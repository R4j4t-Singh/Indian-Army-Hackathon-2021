#!/bin/bash

./question << EOF

12

for var in {1..12}
echo $var
EOF
